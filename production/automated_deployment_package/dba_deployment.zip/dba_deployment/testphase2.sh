DB_PDB_URL="jdbc:oracle:thin:@//10.12.43.240:1521/orclpdb.localdomain?oracle.jdbc.restrictGetTables=false&internal_logon=sysdba"
DB_USER="sys"
DB_PASS="pass"
FLYWAY_COMMON_OPTS="-user=$DB_USER -password=$DB_PASS -schemas=FLYWAY_HISTORY"

# --- PHASE 2: External Data Load and V1.0.4 Marker (DIRECT RUN) ---
echo "--- 2. PHASE 2: External Data Load (V1.0.4) ---"

echo "--- 2a. Starting SQLLoader ---"

# Execute SQLLoader using 'su - oracle -c'
su - oracle -c "sqlldr stock_user/pass@ORCLPDB control=/opt/dba_deployment/data/stocks.ctl log=/opt/dba_deployment/log/stocks.log"

if [ $? -ne 0 ]; then
    echo "ERROR: SQLLoader data load failed. Deployment incomplete."
    exit 1
fi

echo "SQLLoader data load complete. Applying Flyway marker (V1.0.4)."

# 2b. RUN FLYWAY MIGRATION AGAIN to apply the empty V1.0.4 marker script
flyway -url="$DB_PDB_URL" $FLYWAY_COMMON_OPTS migrate

if [ $? -ne 0 ]; then
    echo "ERROR: Flyway V1.0.4 marker application failed. Manual check required."
    exit 1
fi
