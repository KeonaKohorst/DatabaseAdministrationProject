#!/bin/bash
#-----------------------------------------------------------------------
# Script: simulate_pitr_restore.sh
# Purpose: Simulates a user disaster (mass DELETE) in ORCLPDB and restores
#          the PDB to a Point-in-Time (PITR) before the disaster occurred.
# Execution: Run manually by the Oracle user.
#-----------------------------------------------------------------------

# --- Environment Setup ---
export ORACLE_SID=cdb1
export ORAENV_ASK=NO
export ORACLE_BASE=/u01/app/oracle

# PDB specific configuration
TARGET_PDB='ORCLPDB'
USER_TO_IMPERSONATE='STOCK_USER'
TABLE_NAME='STOCKS'

# Determine ORACLE_HOME
export ORACLE_HOME=$(cat /etc/oratab | grep -E "^$ORACLE_SID:" | cut -d ':' -f 2)
if [ -z "$ORACLE_HOME" ]; then
    export ORACLE_HOME="/u01/app/oracle/product/19.0.0/dbhome_1"
fi
export PATH=$ORACLE_HOME/bin:$PATH
export NLS_DATE_FORMAT='DD-MON-YYYY HH24:MI:SS'


# --- Logging Configuration ---
LOG_DIR="$ORACLE_BASE/admin/$ORACLE_SID/logs/rman"
LOG_FILE="$LOG_DIR/pitr_simulation_$(date +\%Y\%m\%d_\%H\%M\%S).log"
mkdir -p $LOG_DIR

echo "========================================================================" | tee -a $LOG_FILE
echo "Starting Data Loss Simulation and PITR at $(date)" | tee -a $LOG_FILE
echo "Target PDB: ${TARGET_PDB}" | tee -a $LOG_FILE
echo "========================================================================" | tee -a $LOG_FILE

# --- 1. INITIALIZATION: Ensure PDB is open for R/W ---
echo "1. Initializing: Ensuring PDB ${TARGET_PDB} is open for READ WRITE." | tee -a $LOG_FILE
sqlplus -s / as sysdba << EOF >> $LOG_FILE
-- Open the PDB if it's not already open. This is essential for all queries.
ALTER PLUGGABLE DATABASE ${TARGET_PDB} OPEN;
EXIT;
EOF


# --- 2. PRE-CHECK: Get initial row count ---
echo "2. Checking initial row count in ${TARGET_PDB}..." | tee -a $LOG_FILE
INITIAL_ROWS=$(sqlplus -s / as sysdba << EOF
SET HEAD OFF FEED OFF;
ALTER SESSION SET CONTAINER = ${TARGET_PDB};
SELECT COUNT(*) FROM ${USER_TO_IMPERSONATE}.${TABLE_NAME};
EXIT;
EOF
)
# Use tr to clean up whitespace for the comparison later
INITIAL_ROWS=$(echo "$INITIAL_ROWS" | tr -d '[:space:]')
echo "Initial Rows in ${TABLE_NAME}: ${INITIAL_ROWS}" | tee -a $LOG_FILE

# --- 3. DISASTER SIMULATION ---
# Capture the current timestamp BEFORE the DELETE for our recovery point.
RECOVERY_UNTIL_TIME=$(date +"%Y-%m-%d %H:%M:%S")

echo "3. Simulating disaster: Deleting 10,000 rows from ${TABLE_NAME} in ${TARGET_PDB}." | tee -a $LOG_FILE
sqlplus -s / as sysdba << EOF >> $LOG_FILE
-- 1. Switch the container to the PDB
ALTER SESSION SET CONTAINER = ${TARGET_PDB};

-- 2. Temporarily set the current schema to the target user (STOCK_USER)
ALTER SESSION SET CURRENT_SCHEMA = ${USER_TO_IMPERSONATE};

-- Run the destructive command to delete a SUBSET of rows
DELETE FROM ${TABLE_NAME} WHERE ROWNUM <= 10000;

-- Commit the deletion to make it permanent
COMMIT;
EXIT;
EOF

# Check post-disaster row count
echo "Checking post-disaster row count..." | tee -a $LOG_FILE
DELETED_ROWS=$(sqlplus -s / as sysdba << EOF
SET HEAD OFF FEED OFF;
ALTER SESSION SET CONTAINER = ${TARGET_PDB};
SELECT COUNT(*) FROM ${USER_TO_IMPERSONATE}.${TABLE_NAME};
EXIT;
EOF
)
DELETED_ROWS=$(echo "$DELETED_ROWS" | tr -d '[:space:]')
echo "POST-DISASTER Rows in ${TABLE_NAME}: ${DELETED_ROWS}" | tee -a $LOG_FILE

# Check if the row count is less than the initial count (i.e., data was deleted)
if [ "$DELETED_ROWS" -lt "$INITIAL_ROWS" ]; then
    echo "Disaster confirmed: Data deleted. Proceeding with recovery." | tee -a $LOG_FILE
else
    echo "ERROR: Data deletion failed or no rows were deleted. Cannot proceed with recovery simulation. Exiting." | tee -a $LOG_FILE
    exit 1
fi

# --- 4. PDB CLOSURE (REQUIRED FOR RMAN) ---
echo "4. Closing PDB ${TARGET_PDB} before RMAN restore." | tee -a $LOG_FILE
sqlplus -s / as sysdba << EOF >> $LOG_FILE
-- The PDB must be closed before RMAN can perform a RESTORE/RECOVER.
ALTER PLUGGABLE DATABASE ${TARGET_PDB} CLOSE IMMEDIATE;
EXIT;
EOF


# --- 5. POINT-IN-TIME RECOVERY (PITR) ---
echo "5. Starting RMAN PITR process..." | tee -a $LOG_FILE
echo "Recovery Target Time: ${RECOVERY_UNTIL_TIME}" | tee -a $LOG_FILE

rman target / log=$LOG_FILE append << RMAN_EOF
set echo on;
RUN {
    # 1. Ensure the CDB is in MOUNT state
    SHUTDOWN IMMEDIATE;
    STARTUP MOUNT;

    # 2. Restore the PDB datafiles from the last available backup
    RESTORE PLUGGABLE DATABASE ${TARGET_PDB} UNTIL TIME "TO_DATE('${RECOVERY_UNTIL_TIME}','YYYY-MM-DD HH24:MI:SS')";

    # 3. FIX: Open the CDB in READ WRITE mode before PDB recovery
    ALTER DATABASE OPEN;

    # 4. Apply recovery (archive logs) up to the specified UNTIL TIME
    RECOVER PLUGGABLE DATABASE ${TARGET_PDB} UNTIL TIME "TO_DATE('${RECOVERY_UNTIL_TIME}','YYYY-MM-DD HH24:MI:SS')";

    # 5. Open the PDB with RESETLOGS (required after PITR)
    ALTER PLUGGABLE DATABASE ${TARGET_PDB} OPEN RESETLOGS;
}
EXIT;
RMAN_EOF

RMAN_STATUS=$?

if [ $RMAN_STATUS -eq 0 ]; then
    echo "RMAN PITR completed successfully." | tee -a $LOG_FILE
else
    echo "ERROR: RMAN PITR failed (Status: $RMAN_STATUS). Check the RMAN log in $LOG_FILE." | tee -a $LOG_FILE
    # Attempt to open the CDB root, but the PDB state may be unknown
    sqlplus -s / as sysdba << EOF >> $LOG_FILE
    -- Attempt to open the CDB if it's still mounted
    ALTER DATABASE OPEN;
    EXIT;
EOF
    exit 1
fi

# --- 6. VERIFICATION ---
echo "6. Checking final row count after recovery..." | tee -a $LOG_FILE
RECOVERED_ROWS=$(sqlplus -s / as sysdba << EOF
SET HEAD OFF FEED OFF;
ALTER SESSION SET CONTAINER = ${TARGET_PDB};
SELECT COUNT(*) FROM ${USER_TO_IMPERSONATE}.${TABLE_NAME};
EXIT;
EOF
)
RECOVERED_ROWS=$(echo "$RECOVERED_ROWS" | tr -d '[:space:]')

echo "RECOVERED Rows in ${TABLE_NAME}: ${RECOVERED_ROWS}" | tee -a $LOG_FILE

if [ "$RECOVERED_ROWS" -eq "$INITIAL_ROWS" ]; then
    echo "SUCCESS: Recovery confirmed. Initial count ($INITIAL_ROWS) matches recovered count ($RECOVERED_ROWS)." | tee -a $LOG_FILE
else
    echo "FAILURE: Recovery may have partially failed. Initial count ($INITIAL_ROWS) does not match recovered count ($RECOVERED_ROWS)." | tee -a $LOG_FILE
fi

echo "========================================================================" | tee -a $LOG_FILE
echo "Simulation finished at $(date)" | tee -a $LOG_FILE
echo "========================================================================" | tee -a $LOG_FILE

exit 0
