#!/bin/bash

#-----------------------------------------------------------------------

# Script: rman_daily_coldbu_cdb1.sh

# Purpose: Executes a daily COLD (offline) full database backup for the cdb1 

#          container database (CDB). This ensures a consistent backup state.

# Execution: Scheduled via cron daily.

# DISADVANTAGE: Requires downtime during the backup process.

#-----------------------------------------------------------------------



# --- Environment Setup (CRON-Ready Fixes Retained) ---

export ORACLE_SID=cdb1

export ORAENV_ASK=NO

export ORACLE_BASE=/u01/app/oracle



# Determine ORACLE_HOME by reading the system /etc/oratab file.

export ORACLE_HOME=$(cat /etc/oratab | grep -E "^$ORACLE_SID:" | cut -d ':' -f 2)



# Fallback to a common path if oratab reading fails or is inaccurate

if [ -z "$ORACLE_HOME" ]; then

    export ORACLE_HOME="/u01/app/oracle/product/19.0.0/dbhome_1" # Adjust if version changes

fi

export PATH=$ORACLE_HOME/bin:$PATH

export NLS_DATE_FORMAT='DD-MON-YYYY HH24:MI:SS'



# --- Logging Configuration ---

LOG_DIR="$ORACLE_BASE/admin/cdb1/logs/rman"

LOG_FILE="$LOG_DIR/daily_coldbu_$(date +\%Y\%m\%d).log"



# Create log directory if it doesn't exist

mkdir -p $LOG_DIR



echo "========================================================================" | tee -a $LOG_FILE

echo "Starting Daily COLD (Offline) Database Backup at $(date)" | tee -a $LOG_FILE

echo "Estimated Downtime: Database will be down for SHUTDOWN, BACKUP, and STARTUP." | tee -a $LOG_FILE

echo "========================================================================" | tee -a $LOG_FILE



# --- 1. SHUTDOWN IMMEDIATE (Stop all activity to ensure consistency) ---

echo "1. Attempting to SHUTDOWN IMMEDIATE..." | tee -a $LOG_FILE

sqlplus -s / as sysdba << EOF >> $LOG_FILE

SHUTDOWN IMMEDIATE;

EXIT;

EOF



# Check if shutdown was successful (status must be 0)

if [ $? -ne 0 ]; then

    echo "ERROR: Database SHUTDOWN failed. Check logs for details. Exiting backup." | tee -a $LOG_FILE

    exit 1

fi

echo "Database successfully shut down." | tee -a $LOG_FILE



# --- 2. STARTUP MOUNT (Database must be mounted for RMAN) ---

echo "2. Attempting to STARTUP MOUNT..." | tee -a $LOG_FILE

sqlplus -s / as sysdba << EOF >> $LOG_FILE

STARTUP MOUNT;

EXIT;

EOF



if [ $? -ne 0 ]; then

    echo "ERROR: Database STARTUP MOUNT failed. Check logs for details. Exiting backup." | tee -a $LOG_FILE

    exit 1

fi

echo "Database successfully mounted." | tee -a $LOG_FILE



# --- 3. RMAN Execution (COLD Backup and Cleanup) ---

echo "3. Starting RMAN COLD Backup and Cleanup..." | tee -a $LOG_FILE



rman target / log=$LOG_FILE append << RMAN_EOF

set echo on;

RUN {

    # Take the COLD Full Backup while the database is mounted. 

    # This backup is guaranteed to be consistent, so no archivelogs are needed.

    BACKUP

      AS BACKUPSET

      DATABASE;



    # Cleanup: Delete all backups (fulls and archivelogs) that are no longer

    # required to satisfy the configured 7-day RECOVERY WINDOW.

    DELETE NOPROMPT OBSOLETE;

}

EXIT;

RMAN_EOF



RMAN_STATUS=$?



# --- 4. OPEN DATABASE (Restore service) ---

echo "4. Attempting to ALTER DATABASE OPEN..." | tee -a $LOG_FILE

sqlplus -s / as sysdba << EOF >> $LOG_FILE

ALTER DATABASE OPEN;

EXIT;

EOF



# Check the status of the RMAN command (RMAN_STATUS is set above)

if [ $RMAN_STATUS -eq 0 ]; then

    echo "Daily COLD Backup and Cleanup completed successfully at $(date)" | tee -a $LOG_FILE

else

    echo "ERROR: Daily COLD Backup failed (RMAN Status: $RMAN_STATUS). Database was restarted. Check logs for details." | tee -a $LOG_FILE

fi



echo "========================================================================" | tee -a $LOG_FILE

# --- Completion ---

exit $RMAN_STATUS
