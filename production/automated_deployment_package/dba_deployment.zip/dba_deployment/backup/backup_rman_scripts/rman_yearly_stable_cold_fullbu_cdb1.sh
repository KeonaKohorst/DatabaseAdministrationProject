#!/bin/bash

#-----------------------------------------------------------------------

# Script: rman_yearly_stable_cold_fullbu_cdb1.sh

# Purpose: Executes a stable YEARLY COLD (offline) full compressed database backup

#          for the cdb1 container database (CDB), protected by the KEEP clause.

# Execution: Scheduled via cron yearly (e.g., on Jan 1st).

# DISADVANTAGE: Requires downtime during the backup process.

#-----------------------------------------------------------------------



# --- Environment Setup ---

export ORACLE_SID=cdb1

export ORAENV_ASK=NO

export ORACLE_BASE=/u01/app/oracle



# Determine ORACLE_HOME by reading the system /etc/oratab file.

export ORACLE_HOME=$(cat /etc/oratab | grep -E "^$ORACLE_SID:" | cut -d ':' -f 2)



# Fallback to a common path if oratab reading fails or is inaccurate

if [ -z "$ORACLE_HOME" ]; then

    export ORACLE_HOME="/u01/app/oracle/product/19.0.0/dbhome_1" # Adjust if version changes

fi

export PATH=$ORACLE_HOME/bin:$PATH

export NLS_DATE_FORMAT='DD-MON-YYYY HH24:MI:SS'





# --- Configuration for Yearly Backup ---

# Calculate the date 2 years from now for the KEEP UNTIL TIME clause.

YEARS_TO_KEEP=2

# Using 365.25 days/year for a slightly more accurate date

DAYS_TO_KEEP=$((YEARS_TO_KEEP * 365 + YEARS_TO_KEEP / 4))

KEEP_DATE=$(date -d "+$DAYS_TO_KEEP days" +\%Y-\%m-\%d)



BACKUP_TAG='STABLE_YEARLY_BU'

# New destination path for yearly archives

STABLE_BACKUP_DEST='/u02/rman/cdb1/stable_archives/yearly'



# --- Logging Configuration ---

LOG_DIR="$ORACLE_BASE/admin/cdb1/logs/rman"

LOG_FILE="$LOG_DIR/yearly_stable_coldbu_$(date +\%Y\%m\%d).log"



# Create log directory and the yearly destination if they don't exist

mkdir -p $LOG_DIR

mkdir -p $STABLE_BACKUP_DEST



echo "========================================================================" | tee -a $LOG_FILE

echo "Starting Stable YEARLY COLD (Offline) COMPRESSED Database Backup at $(date)" | tee -a $LOG_FILE

echo "New backup will be kept for ${YEARS_TO_KEEP} years, until: ${KEEP_DATE}" | tee -a $LOG_FILE

echo "========================================================================" | tee -a $LOG_FILE



# --- 1. SHUTDOWN IMMEDIATE (Stop all activity to ensure consistency) ---

echo "1. Attempting to SHUTDOWN IMMEDIATE..." | tee -a $LOG_FILE

sqlplus -s / as sysdba << EOF >> $LOG_FILE

SHUTDOWN IMMEDIATE;

EXIT;

EOF



if [ $? -ne 0 ]; then

    echo "ERROR: Database SHUTDOWN failed. Check logs for details. Exiting backup." | tee -a $LOG_FILE

    exit 1

fi

echo "Database successfully shut down." | tee -a $LOG_FILE



# --- 2. STARTUP MOUNT (Database must be mounted for RMAN) ---

echo "2. Attempting to STARTUP MOUNT..." | tee -a $LOG_FILE

sqlplus -s / as sysdba << EOF >> $LOG_FILE

STARTUP MOUNT;

EXIT;

EOF



if [ $? -ne 0 ]; then

    echo "ERROR: Database STARTUP MOUNT failed. Check logs for details. Exiting backup." | tee -a $LOG_FILE

    exit 1

fi

echo "Database successfully mounted." | tee -a $LOG_FILE



# --- 3. RMAN Execution (COLD Backup and Cleanup) ---

echo "3. Starting RMAN COLD Backup and Cleanup..." | tee -a $LOG_FILE



rman target / log=$LOG_FILE append << RMAN_EOF

set echo on;

RUN {



    # 2. Perform the STABLE YEARLY COLD backup with KEEP protection.

    BACKUP

      AS COMPRESSED BACKUPSET

      DATABASE

      PLUS ARCHIVELOG

      FORMAT '${STABLE_BACKUP_DEST}/yearly_stable_bu_%U'

      TAG '${BACKUP_TAG}'

      KEEP UNTIL TIME "TO_DATE('${KEEP_DATE}','YYYY-MM-DD')";



}

EXIT;

RMAN_EOF



RMAN_STATUS=$?



# --- 4. OPEN DATABASE (Restore service) ---

echo "4. Attempting to ALTER DATABASE OPEN..." | tee -a $LOG_FILE

sqlplus -s / as sysdba << EOF >> $LOG_FILE

ALTER DATABASE OPEN;

EXIT;

EOF



if [ $? -ne 0 ]; then

    echo "ERROR: Database ALTER DATABASE OPEN failed. Service may still be down." | tee -a $LOG_FILE

fi



if [ $RMAN_STATUS -ne 0 ]; then

    echo "ERROR: RMAN backup failed with status $RMAN_STATUS. Check log file: $LOG_FILE" | tee -a $LOG_FILE

    exit 1

else

    echo "SUCCESS: Stable yearly cold compressed backup completed successfully and the database is OPEN." | tee -a $LOG_FILE

fi



exit 0
